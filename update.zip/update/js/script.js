document.addEventListener("DOMContentLoaded", () => {
  const layout = document.querySelector(".login-layout");
  const scene = document.getElementById("plugScene");
  const socket = document.getElementById("socket");
  const plug = document.getElementById("plug");
  const cableSvg = document.getElementById("cableSvg");
  const cablePath = document.getElementById("cablePath");
  const hint = document.getElementById("connectionHint");
  const loginSide = document.getElementById("loginSide");
  const loginForm = document.getElementById("loginForm");
  const studentName = document.getElementById("studentName");
  const studentNim = document.getElementById("studentNim");
  const formMessage = document.getElementById("formMessage");

  let dragging = false;
  let connected = false;
  let pointerOffsetX = 0;
  let pointerOffsetY = 0;

  function getCenter(element) {
    const sceneRect = scene.getBoundingClientRect();
    const rect = element.getBoundingClientRect();
    return { x: rect.left - sceneRect.left + rect.width / 2,
             y: rect.top - sceneRect.top + rect.height / 2 };
  }

  function drawCable() {
    const width = scene.clientWidth, height = scene.clientHeight;
    if (!width || !height) return;
    cableSvg.setAttribute("viewBox", `0 0 ${width} ${height}`);
    const socketCenter = getCenter(socket);
    const plugRect = plug.getBoundingClientRect();
    const sceneRect = scene.getBoundingClientRect();
    const startX = socketCenter.x, startY = socketCenter.y + 30;
    const endX = plugRect.left - sceneRect.left + 2;
    const endY = plugRect.top - sceneRect.top + plugRect.height / 2;
    const distance = Math.abs(endX - startX);
    const bend = Math.max(45, distance * .35);
    const bendY = Math.max(startY, endY) + Math.min(100, distance * .25);
    cablePath.setAttribute("d", `M ${startX} ${startY} C ${startX+bend} ${bendY}, ${endX-bend} ${bendY}, ${endX} ${endY}`);
  }

  function movePlug(clientX, clientY) {
    const rect = scene.getBoundingClientRect();
    plug.style.left = `${clientX - rect.left - pointerOffsetX}px`;
    plug.style.top = `${clientY - rect.top - pointerOffsetY}px`;
    drawCable();
  }

  function isNearSocket() {
    const center = getCenter(socket);
    const rect = plug.getBoundingClientRect();
    const sceneRect = scene.getBoundingClientRect();
    const pinX = rect.left - sceneRect.left - 5;
    const pinY = rect.top - sceneRect.top + rect.height / 2;
    return Math.abs(pinX-center.x) < 65 && Math.abs(pinY-center.y) < 55;
  }

  function connectPlug() {
    if (connected) return;
    connected = true;
    plug.style.cursor = "default";
    plug.style.pointerEvents = "none";
    hint.textContent = "CONNECTION ESTABLISHED ✓";
    scene.classList.add("is-connected");
    const center = getCenter(socket);
    const plugWidth = plug.getBoundingClientRect().width;
    plug.style.transition = "left .35s ease, top .35s ease, box-shadow .35s ease";
    plug.style.left = `${center.x + plugWidth/2 + 5}px`;
    plug.style.top = `${center.y}px`;
    plug.style.boxShadow = "0 0 35px #64f5ff, inset 0 0 18px #64f5ff66";
    let frames = 0;
    function animateCable() { drawCable(); if (++frames < 30) requestAnimationFrame(animateCable); }
    requestAnimationFrame(animateCable);
    setTimeout(() => {
      layout.classList.add("connected");
      loginSide.setAttribute("aria-hidden", "false");
      setTimeout(() => studentName.focus(), 650);
    }, 750);
  }

  plug.addEventListener("pointerdown", (event) => {
    if (connected || event.button === 2) return;
    event.preventDefault();
    dragging = true;
    const center = getCenter(plug);
    const rect = scene.getBoundingClientRect();
    pointerOffsetX = event.clientX - (rect.left + center.x);
    pointerOffsetY = event.clientY - (rect.top + center.y);
    plug.style.transition = "none";
    plug.setPointerCapture(event.pointerId);
    plug.style.cursor = "grabbing";
  });

  plug.addEventListener("pointermove", (event) => {
    if (dragging && !connected) movePlug(event.clientX, event.clientY);
  });

  function finishDrag() {
    if (!dragging) return;
    dragging = false;
    if (isNearSocket()) { connectPlug(); return; }
    plug.style.cursor = "grab";
    plug.style.transition = "left .35s ease, top .35s ease, box-shadow .35s ease";
    plug.style.left = "";
    plug.style.top = "";
    setTimeout(drawCable, 380);
  }

  plug.addEventListener("pointerup", finishDrag);
  plug.addEventListener("pointercancel", finishDrag);
  plug.addEventListener("keydown", (event) => {
    if (!connected && (event.key === "Enter" || event.key === " ")) {
      event.preventDefault(); connectPlug();
    }
  });

  window.addEventListener("resize", drawCable);
  requestAnimationFrame(() => requestAnimationFrame(drawCable));

  loginForm.addEventListener("submit", (event) => {
    event.preventDefault();
    const name = studentName.value.trim();
    const nim = studentNim.value.trim();

    if (!name || !nim) {
      formMessage.textContent = "Nama mahasiswa dan NIM wajib diisi.";
      return;
    }
    if (!/^[0-9]+$/.test(nim)) {
      formMessage.textContent = "NIM hanya boleh berisi angka.";
      studentNim.focus();
      return;
    }

    sessionStorage.setItem("portfolioDemoLogin", "true");
    sessionStorage.setItem("studentName", name);
    sessionStorage.setItem("studentNim", nim);
    window.location.href = "hasil.html";
  });
});
window.addEventListener("resize", () => {
  requestAnimationFrame(drawCable);
});

window.addEventListener("orientationchange", () => {
  setTimeout(drawCable, 150);
});