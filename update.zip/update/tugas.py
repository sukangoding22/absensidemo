import struct
print("Nama          : Riza Ahmadinejad")
print("Prodi         : Sistem Informasi")
print("")

# Nilai yang akan dikonversi
nilai = -20219202561

# Mengubah nilai float menjadi representasi IEEE 754 Single Precision (32-bit)
binary = struct.pack('!f', nilai)

# Mengubah hasil menjadi deretan bit
bit = ''.join(format(byte, '08b') for byte in binary)

# Memisahkan bagian Sign, Exponent, dan Mantissa
sign = bit[0]
exponent = bit[1:9]
mantissa = bit[9:32]

# Menampilkan hasil
print("Nilai Desimal :", nilai)
print("Sign          :", sign)
print("Exponent      :", exponent)
print("Mantissa      :", mantissa)
print("Bit 32-bit    :", bit)

# Menampilkan representasi heksadesimal
print("Hexadecimal   :", binary.hex().upper())